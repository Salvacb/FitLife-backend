// LoginRequest.java
package com.fitlife.api;
public class LoginRequest {
    public String email;
    public String password;
}
