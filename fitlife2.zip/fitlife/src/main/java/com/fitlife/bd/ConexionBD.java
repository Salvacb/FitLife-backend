package com.fitlife.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    private static final String URL = "jdbc:mysql://13.61.161.23:3306/fitlife";
    private static final String USER = "salva";
    private static final String PASS = "1234";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void main(String[] args) {
        System.out.println("🔄 Intentando conectar a la base de datos...");

        try (Connection conn = getConnection()) {
            System.out.println("✅ Conexión a MySQL exitosa.");
        } catch (SQLException e) {
            System.err.println("❌ Error al conectar:");
            System.err.println("URL: " + URL);
            System.err.println("Usuario: " + USER);
            e.printStackTrace();
        }
    }
}
