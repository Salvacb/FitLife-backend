package com.fitlife.servlets;

import com.fitlife.classes.Usuario;
import com.fitlife.dao.UsuarioDAO;
import com.fitlife.utils.SeguridadUtil;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Configuración de respuesta JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Cache-Control", "no-store");

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        try (PrintWriter out = response.getWriter()) {
            JSONObject jsonResponse = new JSONObject();
            Usuario usuario = UsuarioDAO.buscarPorEmail(email);

            if (usuario != null && usuario.getPassword().equals(SeguridadUtil.hashearPassword(password))) {
                // Autenticación exitosa
                jsonResponse.put("cod", "ok");
                jsonResponse.put("msg", "Login exitoso");
                JSONObject data = new JSONObject();
                data.put("id", usuario.getId());
                data.put("nombre", usuario.getNombre());
                data.put("email", usuario.getEmail());
                // añadir más campos si es necesario
                jsonResponse.put("res", data);
            } else {
                // Error de autenticación
                jsonResponse.put("cod", "ERROR");
                jsonResponse.put("msg", "Credenciales inválidas");
            }

            out.write(jsonResponse.toString());

        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error en el servidor");
            e.printStackTrace();
        }
    }
}
